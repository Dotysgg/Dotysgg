# Growtopia-CID-Creator-v4
🔥Growtopia CID v4 | Updated Anti Invalids | Create 80 accounts per minute🔥
